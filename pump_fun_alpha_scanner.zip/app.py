from flask import Flask, render_template_string
import random

app = Flask(__name__)

meme_keywords = ["inu", "pepe", "elon", "wife", "69", "bonk", "moon", "pump", "dump"]

tagged_wallets = {
    "9xFr...": "Whale",
    "1Abc...": "Influencer",
}

def get_mocked_coin_data():
    coins = []
    for i in range(5):
        name = random.choice(["Bonk Inu", "MoonWife69", "ElonDump", "PepeGold", "ShibaPump"])
        ticker = f"${name.upper()[:4]}"
        buys = random.randint(5, 100)
        lp_fill = f"{random.randint(10, 90)} sec"
        wallets = random.choices(list(tagged_wallets.keys()) + ["Unknown"], k=2)
        meme_score = sum(1 for word in meme_keywords if word.lower() in name.lower())
        coins.append({
            "name": name,
            "ticker": ticker,
            "buys": buys,
            "lp_fill": lp_fill,
            "wallets": wallets,
            "meme_score": meme_score,
        })
    return coins

template = """<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <title>Pump.fun Insider Scanner</title>
    <style>
        body { background-color: #121212; color: white; font-family: Arial, sans-serif; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #333; }
        th { background-color: #1e1e1e; }
        tr:hover { background-color: #2a2a2a; }
        .hot { color: #ff5959; }
        .warm { color: #ffaa00; }
        .cool { color: #00ccff; }
    </style>
</head>
<body>
    <h1>🚀 Pump.fun Insider Scanner (Live)</h1>
    <table>
        <tr>
            <th>Token</th>
            <th>Ticker</th>
            <th>Buys</th>
            <th>LP Fill</th>
            <th>Wallets</th>
            <th>Meme Score</th>
        </tr>
        {% for coin in coins %}
        <tr>
            <td>{{ coin.name }}</td>
            <td>{{ coin.ticker }}</td>
            <td>{{ coin.buys }}</td>
            <td>{{ coin.lp_fill }}</td>
            <td>
                {% for wallet in coin.wallets %}
                    {{ wallet }}{% if wallet in tagged_wallets %} ({{ tagged_wallets[wallet] }}){% endif %}<br>
                {% endfor %}
            </td>
            <td class="{% if coin.meme_score >= 3 %}hot{% elif coin.meme_score == 2 %}warm{% else %}cool{% endif %}">
                {{ coin.meme_score }}/10
            </td>
        </tr>
        {% endfor %}
    </table>
</body>
</html>"""

@app.route("/")
def index():
    coins = get_mocked_coin_data()
    return render_template_string(template, coins=coins, tagged_wallets=tagged_wallets)

if __name__ == "__main__":
    app.run(debug=False, port=5000)
